<!--[if !(lt IE 8)]><!-->
<script type="text/javascript"> 
  // The defaults are set below
  var banner_config = {
    disableDate: false, // If true, the banner shows even if the date is not yet 06/21/2016. Use for testing.
    debug: false // Reveals any errors and debug messages. For debugging purposes only.
  };
  (function(){
    var e = document.createElement('script'); e.type='text/javascript'; e.async = true;
    e.src = 'https://www.eff.org/doa/widget.min.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(e, s);
  })();
</script>
<!--<![endif]-->